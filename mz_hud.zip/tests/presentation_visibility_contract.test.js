const assert = require('node:assert/strict');
const fs = require('node:fs');
const test = require('node:test');

const read = path => fs.readFileSync(path, 'utf8');

test('external suppressors can preserve only the logo without weakening default suppression', () => {
  const client = read('client/main.lua');
  const state = read('web/app/state.js');
  const events = read('web/app/events.js');
  const render = read('web/app/render.js');

  assert.match(client, /options\.keepLogo == true/);
  assert.match(client, /keepLogo and 'logo-only' or 'all'/);
  assert.match(client, /logoVisible = isLogoEffectivelyVisible\(\)/);
  assert.match(state, /logoVisible:\s*true/);
  assert.match(events, /state\.logoVisible = data\.logoVisible/);
  assert.match(events, /state\.logoVisible[\s\S]*app\.renderHud\(\);/);
  assert.match(render, /if \(!state\.logoVisible\) dom\.hudLogo\.classList\.add\("hidden"\)/);
  assert.match(render, /!state\.hudVisible \|\| !state\.speedometerVisible/);
});
