const assert = require('node:assert/strict');
const fs = require('node:fs');
const test = require('node:test');
const vm = require('node:vm');

const read = path => fs.readFileSync(path, 'utf8');

test('medical presentation keeps distinct downed and dead states with an animated monitor', () => {
  const events = read('web/app/events.js');
  const styles = read('web/hud/medical/medical.css');
  const index = read('web/index.html');
  const manifest = read('fxmanifest.lua');

  assert.match(events, /downed:\s*\{[\s\S]*title:\s*"NOCAUTEADO"/);
  assert.match(events, /dead:\s*\{[\s\S]*title:\s*"MORTO"/);
  assert.match(events, /data-medical-timer-value/);
  assert.match(events, /medical-wave-trace/);
  assert.match(styles, /@keyframes medical-heart-beat/);
  assert.match(styles, /@keyframes medical-wave-travel/);
  assert.match(styles, /\.medical-dead \.medical-wave-trace/);
  assert.match(index, /hud\/medical\/medical\.css/);
  assert.match(manifest, /web\/hud\/medical\/medical\.css/);
});

test('medical renderer updates the clock without rebuilding the heartbeat animation', () => {
  const children = new Map();
  const makeChild = () => ({
    hidden: false,
    textContent: '',
    classList: { toggle(_, hidden) { this.owner.hidden = hidden; }, owner: null },
  });
  const addChild = selector => {
    const child = makeChild();
    child.classList.owner = child;
    children.set(selector, child);
  };
  const target = {
    className: 'medical-hud hidden',
    dataset: {},
    writes: 0,
    _html: '',
    classList: { add() {} },
    querySelector(selector) { return children.get(selector) || null; },
    set innerHTML(value) {
      this._html = value;
      children.clear();
      if (!value) return;
      this.writes += 1;
      addChild('[data-medical-timer-label]');
      addChild('[data-medical-timer-value]');
      addChild('[data-medical-action="help"]');
      addChild('[data-medical-action="respawn"]');
      addChild('[data-medical-action="treatment"]');
    },
    get innerHTML() { return this._html; },
  };

  const app = {
    state: {},
    dom: { medicalHud: target },
    helpers: { escapeHTML: value => String(value) },
    getEditorModule() {},
    getEditorPresetModule() {},
  };
  const context = {
    window: {
      MZHudApp: app,
      addEventListener() {},
    },
    Object,
    Math,
    Number,
    String,
  };

  vm.runInNewContext(read('web/app/events.js'), context);
  const messageHandler = app.handleMessage;
  const send = medical => messageHandler({ data: { action: 'updateMedical', medical } });

  send({ state: 'downed', remaining: 247, helpEnabled: true });
  assert.equal(target.className, 'medical-hud medical-downed');
  assert.equal(children.get('[data-medical-timer-value]').textContent, '4:07');
  assert.equal(children.get('[data-medical-action="help"]').hidden, false);
  assert.equal(target.writes, 1);

  send({ state: 'downed', remaining: 246, helpEnabled: true });
  assert.equal(children.get('[data-medical-timer-value]').textContent, '4:06');
  assert.equal(target.writes, 1, 'same state should preserve the running CSS animation');

  send({ state: 'dead', remaining: 0, helpEnabled: true, respawnAvailable: true });
  assert.equal(target.className, 'medical-hud medical-dead medical-ready');
  assert.equal(children.get('[data-medical-timer-label]').textContent, 'RESPAWN HOSPITALAR LIBERADO');
  assert.equal(children.get('[data-medical-action="respawn"]').hidden, false);
  assert.equal(target.writes, 2);
});
