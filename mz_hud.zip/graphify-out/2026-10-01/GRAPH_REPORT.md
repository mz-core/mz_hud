# Graph Report - mz_hud  (2026-09-21)

## Corpus Check
- 66 files · ~51,496 words
- Verdict: corpus is large enough that graph structure adds value.

## Summary
- 355 nodes · 705 edges · 38 communities (35 shown, 3 thin omitted)
- Extraction: 96% EXTRACTED · 4% INFERRED · 0% AMBIGUOUS · INFERRED: 28 edges (avg confidence: 0.87)
- Token cost: 0 input · 0 output

## Graph Freshness
- Built from commit: `b73fe3a7`
- Run `git rev-parse HEAD` and compare to check if the graph is stale.
- Run `graphify update .` after code changes (no API cost).

## Community Hubs (Navigation)
- server/main.lua
- client/main.lua
- icons.js
- DraftStore
- create
- mz_hud Resource Architecture
- speedometer.js
- defaults.js
- mz_hud Documentation Hub
- Administrative Command Surface
- Configurable Icon System
- schema.js
- create
- Global Preset Catalog
- applyCanonicalPlayerState
- Local Administrative Audit Log
- utils.js
- status.js
- voice.js
- presentation_visibility_contract.test.js

## God Nodes (most connected - your core abstractions)
1. `create()` - 25 edges
2. `sanitizeHudConfig()` - 19 edges
3. `DraftStore` - 17 edges
4. `applyPresetForSource()` - 16 edges
5. `bind()` - 16 edges
6. `writeAudit()` - 15 edges
7. `restoreBackupForSource()` - 15 edges
8. `buildDiagnosticReport()` - 15 edges
9. `getDefaults()` - 12 edges
10. `createRuntimeBackup()` - 12 edges

## Surprising Connections (you probably didn't know these)
- `Icon Path Conventions` --semantically_similar_to--> `Sequential Icon Discovery`  [INFERRED] [semantically similar]
  web/assets/icons/ICON_PATHS.md → docs/ICON_SYSTEM.md
- `Icon Asset Guide` --semantically_similar_to--> `Style and Icon Separation`  [INFERRED] [semantically similar]
  web/assets/icons/README.md → docs/ICON_SYSTEM.md
- `Frontend Module Load Order` --conceptually_related_to--> `mz_hud Resource Architecture`  [INFERRED]
  web/index.html → docs/STRUCTURE.md
- `Visual Editor DOM` --conceptually_related_to--> `Visual Editor v2`  [INFERRED]
  web/index.html → docs/VISUAL_EDITOR.md
- `Administrative Toolkit` --references--> `Administrative Backup Storage`  [EXTRACTED]
  docs/ADMIN_TOOLS.md → data/backups/README.md

## Import Cycles
- None detected.

## Hyperedges (group relationships)
- **Configurable Icon Convention** — docs_icon_system_configurable_icon_system, docs_icon_system_sequential_icon_discovery, web_assets_icons_icon_paths_icon_path_conventions, web_assets_icons_readme_icon_asset_guide [INFERRED 0.85]
- **Global Configuration Safety** — readme_global_configuration_flow, docs_admin_tools_backup_change_diagnose_workflow, docs_production_mode_production_safety_guide, docs_release_checklist_release_validation [INFERRED 0.85]
- **Visual Editor Delivery Flow** — docs_editor_guide_draft_first_editor_workflow, docs_visual_editor_visual_editor_v2, tests_editor_preview_local_editor_preview, web_index_visual_editor_dom [INFERRED 0.85]

## Communities (38 total, 3 thin omitted)

### Community 0 - "server/main.lua"
Cohesion: 0.09
Nodes (73): applyPresetForSource(), areBackupsEnabled(), broadcastConfig(), buildDiagnosticReport(), buildEditorPresetManager(), checkRequiredHudFiles(), clampNumber(), countTableEntries() (+65 more)

### Community 1 - "client/main.lua"
Cohesion: 0.10
Nodes (36): applyChatLayout(), applyMinimapPositions(), applyMinimapSettings(), applySeatbeltCrashEffect(), buildMinimapSignature(), buildPayloadSignature(), clamp(), clearNuiPayloadCache() (+28 more)

### Community 2 - "icons.js"
Cohesion: 0.15
Nodes (29): addIconEntry(), applyManifest(), bootstrapIconCatalog(), deepCloneCatalog(), ensureCategory(), escapeAttr(), fetchManifest(), getElementFallbackIcon() (+21 more)

### Community 3 - "DraftStore"
Cohesion: 0.11
Nodes (9): assert, { DraftStore }, fs, path, schema, visibility, DraftStore, resolveVisibility() (+1 more)

### Community 4 - "create"
Cohesion: 0.20
Nodes (25): create(), bind(), closeEditor(), commonInspector(), discardAndClose(), endPointer(), hideInspector(), isLocked() (+17 more)

### Community 5 - "mz_hud Resource Architecture"
Cohesion: 0.15
Nodes (16): Draft-first Editor Workflow, Server-authoritative Save, Legacy Web Config, Lua to NUI Render Pipeline, mz_hud Resource Architecture, Closed-schema NUI Security, Optimistic Revision Control, FiveM Runtime Validation Pending (+8 more)

### Community 6 - "speedometer.js"
Cohesion: 0.37
Nodes (15): circleDashOffset(), fallbackIconPath(), icon(), iconSrc(), indicatorIcons(), normalizeSlot(), render(), renderAnalog() (+7 more)

### Community 7 - "defaults.js"
Cohesion: 0.29
Nodes (9): normalizeConfig(), statusGroupInlineStyle(), withChatDefaults(), withCommsOptions(), withElementDefaults(), withSpeedometerDefaults(), withSpeedometerIconDefaults(), withStatusGroupDefaults() (+1 more)

### Community 8 - "mz_hud Documentation Hub"
Cohesion: 0.22
Nodes (11): Administrative Toolkit, Backup Change Diagnose Workflow, Read-only Administrative Diagnostics, Dependency Start Order, mz_hud Installation Sequence, Backup Before Global Change, Production Safety Guide, mz_hud Documentation Hub (+3 more)

### Community 10 - "Administrative Command Surface"
Cohesion: 0.25
Nodes (9): Administrative Backup Storage, Runtime-managed Backups, Explicit Preset Application, Operational Global Presets, Administrative Command Surface, Owner Permission Boundary, Global Configuration Flow, mz_hud Global HUD (+1 more)

### Community 11 - "Configurable Icon System"
Cohesion: 0.29
Nodes (8): Configurable Icon System, Sequential Icon Discovery, Style and Icon Separation, Icon Path Conventions, Supported Icon Formats, Function-specific Icon Folders, Icon Asset Guide, Legacy Icon Fallbacks

### Community 12 - "schema.js"
Cohesion: 0.57
Nodes (6): clamp(), clone(), normalizeConfig(), normalizeElement(), normalizeModule(), oneOf()

### Community 13 - "create"
Cohesion: 0.48
Nodes (6): create(), apply(), bind(), refresh(), render(), setStatus()

### Community 14 - "Global Preset Catalog"
Cohesion: 0.33
Nodes (6): Documentation and Operational Preset Split, Global Preset Catalog, Safe Preset Persistence, Official Style Catalog, Style Compatibility Contract, Style Extension Pipeline

### Community 15 - "applyCanonicalPlayerState"
Cohesion: 0.60
Nodes (4): applyCanonicalPlayerState(), clamp(), MZHudStatusContract.apply(), MZHudStatusContract.create()

### Community 16 - "Local Administrative Audit Log"
Cohesion: 0.50
Nodes (5): Local Administrative Audit Log, Sensitive Data Exclusion, Phased Project Evolution, Runtime Contract Preservation, Release Validation Checklist

### Community 37 - "presentation_visibility_contract.test.js"
Cohesion: 0.40
Nodes (3): assert, fs, test

## Knowledge Gaps
- **17 isolated node(s):** `assert`, `fs`, `path`, `schema`, `visibility` (+12 more)
  These have ≤1 connection - possible missing edges or undocumented components.
- **3 thin communities (<3 nodes) omitted from report** — run `graphify query` to explore isolated nodes.

## Suggested Questions
_Questions this graph is uniquely positioned to answer:_

- **Why does `mz_hud Documentation Hub` connect `mz_hud Documentation Hub` to `mz_hud Resource Architecture`, `Administrative Command Surface`, `Configurable Icon System`, `Global Preset Catalog`, `Local Administrative Audit Log`?**
  _High betweenness centrality (0.014) - this node is a cross-community bridge._
- **Why does `Configurable Icon System` connect `Configurable Icon System` to `mz_hud Documentation Hub`, `Administrative Command Surface`, `mz_hud Resource Architecture`?**
  _High betweenness centrality (0.006) - this node is a cross-community bridge._
- **Are the 5 inferred relationships involving `create()` (e.g. with `closeEditor()` and `openEditor()`) actually correct?**
  _`create()` has 5 INFERRED edges - model-reasoned connections that need verification._
- **Are the 2 inferred relationships involving `bind()` (e.g. with `endPointer()` and `movePointer()`) actually correct?**
  _`bind()` has 2 INFERRED edges - model-reasoned connections that need verification._
- **What connects `assert`, `fs`, `path` to the rest of the system?**
  _17 weakly-connected nodes found - possible documentation gaps or missing edges._
- **Should `server/main.lua` be split into smaller, more focused modules?**
  _Cohesion score 0.09117117117117117 - nodes in this community are weakly interconnected._
- **Should `client/main.lua` be split into smaller, more focused modules?**
  _Cohesion score 0.10121457489878542 - nodes in this community are weakly interconnected._